<?php

add_ux_builder_shortcode( '_root', array(
    'type' => 'container',
    'name' => __( 'Content' ),
    'external' => true,
    'hidden' => true,
    'wrap' => false,
    'addable_spots' => array( 'center' ),
) );
